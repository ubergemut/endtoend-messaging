module Hacl.Streaming.Poly1305_32

module G = FStar.Ghost
module F = Hacl.Streaming.Functor
module I = Hacl.Streaming.Interface

open Hacl.Impl.Poly1305.Fields
open Hacl.Streaming.Poly1305

#set-options "--fuel 0 --ifuel 0 --z3rlimit 100"

/// Type abbreviation - makes KaRaMeL use pretty names in the generated code
let state_t = F.state_s (poly1305 M32) () (t M32) (poly1305_key.I.s ())

noextract
let alloca = F.alloca (poly1305 M32) () (t M32) (poly1305_key.I.s ())
let malloc = F.malloc (poly1305 M32) () (t M32) (poly1305_key.I.s ())
let reset = F.reset (poly1305 M32) (G.hide ()) (t M32) (poly1305_key.I.s ())
[@@ Comment "0 = success, 1 = max length exceeded" ]
let update = F.update (poly1305 M32) (G.hide ()) (t M32) (poly1305_key.I.s ())
let digest = F.digest (poly1305 M32) () (t M32) (poly1305_key.I.s ())
let free = F.free (poly1305 M32) (G.hide ()) (t M32) (poly1305_key.I.s ())

open Hacl.Impl.Poly1305

(* The one-shot MAC *)
val mac: poly1305_mac_st M32
