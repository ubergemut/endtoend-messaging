module.exports = 'extramodule2';
