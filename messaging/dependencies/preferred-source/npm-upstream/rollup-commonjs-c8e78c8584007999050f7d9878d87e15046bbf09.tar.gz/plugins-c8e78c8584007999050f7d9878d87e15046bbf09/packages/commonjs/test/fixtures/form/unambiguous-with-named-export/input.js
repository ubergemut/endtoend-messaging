require( './foo.js' );

export {};
