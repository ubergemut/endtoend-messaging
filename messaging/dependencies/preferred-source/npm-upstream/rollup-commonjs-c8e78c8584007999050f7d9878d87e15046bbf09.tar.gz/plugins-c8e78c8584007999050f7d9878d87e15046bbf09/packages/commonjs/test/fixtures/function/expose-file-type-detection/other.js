module.exports = 'foo';
