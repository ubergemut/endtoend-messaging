module.exports = 'same-directory';
