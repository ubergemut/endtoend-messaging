module.exports = 'submodule1';
