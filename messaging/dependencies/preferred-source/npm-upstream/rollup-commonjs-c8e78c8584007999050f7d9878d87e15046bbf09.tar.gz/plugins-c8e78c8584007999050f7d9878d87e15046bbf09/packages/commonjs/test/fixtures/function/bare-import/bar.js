Math.bar = 42;
