module.exports = 'fubar';
