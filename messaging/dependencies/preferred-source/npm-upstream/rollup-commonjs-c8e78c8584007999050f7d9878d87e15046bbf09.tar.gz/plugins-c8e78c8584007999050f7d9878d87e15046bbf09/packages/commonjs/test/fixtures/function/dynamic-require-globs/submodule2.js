module.exports = 'submodule2';
