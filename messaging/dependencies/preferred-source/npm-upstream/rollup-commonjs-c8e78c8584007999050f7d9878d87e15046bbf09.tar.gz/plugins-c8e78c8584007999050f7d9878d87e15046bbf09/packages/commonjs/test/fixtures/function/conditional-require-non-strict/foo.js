global.foo = true;
