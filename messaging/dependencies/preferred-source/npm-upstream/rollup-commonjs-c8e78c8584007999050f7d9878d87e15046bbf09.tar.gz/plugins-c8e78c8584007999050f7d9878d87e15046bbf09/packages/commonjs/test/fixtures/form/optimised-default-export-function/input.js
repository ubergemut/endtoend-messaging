module.exports = function foo () {};
