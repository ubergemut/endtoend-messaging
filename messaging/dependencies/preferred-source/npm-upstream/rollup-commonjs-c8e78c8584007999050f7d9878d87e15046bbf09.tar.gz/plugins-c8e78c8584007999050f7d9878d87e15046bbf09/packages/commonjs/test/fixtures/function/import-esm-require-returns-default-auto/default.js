export default 'bar';
