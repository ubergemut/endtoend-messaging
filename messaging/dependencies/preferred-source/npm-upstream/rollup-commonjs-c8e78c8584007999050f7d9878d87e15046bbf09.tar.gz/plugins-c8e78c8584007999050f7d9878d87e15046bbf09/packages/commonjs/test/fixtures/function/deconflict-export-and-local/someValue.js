exports.someValue = 10;
