global.bar = true;
