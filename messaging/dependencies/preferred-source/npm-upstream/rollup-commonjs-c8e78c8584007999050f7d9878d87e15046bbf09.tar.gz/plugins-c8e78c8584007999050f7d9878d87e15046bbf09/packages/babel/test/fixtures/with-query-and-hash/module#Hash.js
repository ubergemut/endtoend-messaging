export default class WithHash {}
