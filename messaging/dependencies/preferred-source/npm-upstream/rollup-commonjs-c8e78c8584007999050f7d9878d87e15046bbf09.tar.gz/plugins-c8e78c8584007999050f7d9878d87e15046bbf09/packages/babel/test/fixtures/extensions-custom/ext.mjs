export default class Mjs {}
