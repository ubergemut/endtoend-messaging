export default class Bar {}
