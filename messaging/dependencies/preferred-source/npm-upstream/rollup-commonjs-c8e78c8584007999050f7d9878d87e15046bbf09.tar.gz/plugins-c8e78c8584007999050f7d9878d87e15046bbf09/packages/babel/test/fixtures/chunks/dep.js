export default () => 42;
