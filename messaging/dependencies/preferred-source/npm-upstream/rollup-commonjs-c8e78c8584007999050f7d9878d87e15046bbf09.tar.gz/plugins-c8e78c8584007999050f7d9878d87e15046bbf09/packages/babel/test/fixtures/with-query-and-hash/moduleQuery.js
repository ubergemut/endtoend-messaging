export default class WithQuery {}
