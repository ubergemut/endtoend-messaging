export default class Js {}
