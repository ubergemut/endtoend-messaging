export default class WithQueryAndHash {}
