export const qux = 'QUX';
