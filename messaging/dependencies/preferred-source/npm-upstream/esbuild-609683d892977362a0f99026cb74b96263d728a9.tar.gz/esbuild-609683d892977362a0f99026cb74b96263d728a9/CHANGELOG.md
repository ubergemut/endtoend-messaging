# Changelog

## 0.28.2

* Fix tree shaking bug due to TypeScript import alias ([#4507](https://github.com/evanw/esbuild/issues/4507))

    This release fixes a bug that could cause esbuild to incorrectly tree-shake imports that are used in a TypeScript type alias under certain circumstances. Affected code uses a TypeScript-specific `import` assignment and looks something like this:

    ```ts
    import Base from './dep.js';
    import Alias = Base.SomeType;
    ```

* Fix CSS minification bug involving `&` ([#4497](https://github.com/evanw/esbuild/issues/4497))

    This release fixes a bug where esbuild's CSS minifier incorrectly removed a `&` when it was unsafe to do so. Here is an example:

    ```css
    /* Original code */
    .a .b {
      & .b:not(& .c) {
        color: red;
      }
    }

    /* Old output (with --minify) */
    .a .b{.b:not(& .c){color:red}}

    /* New output (with --minify) */
    .a .b{& .b:not(& .c){color:red}}
    ```

    This should match `<span class="a"><span class="b"><span class="b">yes</span></span></span>` but not `<span class="a"><span class="b">no</span></span>`. The old output incorrectly matched both.

* Avoid overwriting input files without `--allow-overwrite` ([#4484](https://github.com/evanw/esbuild/issues/4484))

    For example: `esbuild input.js --outfile=input.js` tells esbuild to overwrite `input.js` with the output of running esbuild on it. This was supposed to already be prevented by default, but it accidentally regressed in version 0.17.0 and apparently didn't have any test coverage. The error message was being printed but the input file was still being overwritten. Oops.

    This release puts the original behavior back. With this release, esbuild should now actually avoid overwriting input files unless `--allow-overwrite` is explicitly present. This is done by not writing out any files when a build error is encountered.

* Fix incorrect code generated when using top-level await ([#4498](https://github.com/evanw/esbuild/issues/4498))

    Previously esbuild could generate code containing a syntax error in complex scenarios involving top-level await used in a dependency cycle. The problem was a missing `async` on one or more module wrapper closures. With this release, esbuild now uses a fixed-point iteration algorithm to correctly annotate all dependencies in the cycle as needing an `async` module wrapper.

* Fix a minification bug with lowered logical assignment operators ([#4508](https://github.com/evanw/esbuild/issues/4508))

    This release fixes a bug that could cause esbuild to generate incorrect code for logical assignment operators when lowering them to an older target environment. Specifically the lowering process requires duplicating the left-hand side, but esbuild incorrectly failed to count the duplicate as a new usage when the left-hand side is an identifier. That then caused the minifier to believe that the left-hand side was only used once and could attempt to incorrectly inline an initializer into the first usage. This bug has now been fixed:

    ```js
    // Original code
    function foo() {
      let x
      bar(x ||= {})
    }

    // Old output (with --minify-syntax --target=es6)
    function foo() {
      bar(void 0 || (x = {}));
    }

    // New output (with --minify-syntax --target=es6)
    function foo() {
      let x;
      bar(x || (x = {}));
    }
    ```

* Fix a potential deadlock when the JavaScript API is used incorrectly ([#4503](https://github.com/evanw/esbuild/issues/4503), [#4506](https://github.com/evanw/esbuild/pull/4506))

    The JavaScript API runs the native esbuild executable as a long-lived child process and communicates with it over stdin/stdout/stderr. Each API request is asynchronous and the executable stays open as long as it has work to do, which is as long as either stdin is still open (meaning there may be more API requests) or there are currently requests being processed.

    Previously esbuild's tracking of outstanding API requests missed decrementing a reference count in an edge case where esbuild's JavaScript API was used incorrectly and the API request returned an error. This could in some cases cause esbuild's native executable to exit with an error message about a deadlock. This release fixes the reference counting bug.

    This fix was submitted by [@ZuBB](https://github.com/ZuBB).

* Handle target collisions ([#4509](https://github.com/evanw/esbuild/issues/4509))

    It's possible to specify the same target engine multiple times, such as with `--target=chrome1,chrome99`. This edge case wasn't anticipated and previously took the last version for the duplicated target engine instead of the minimum version (so `chrome99` in this case instead of `chrome1`). With this release, esbuild will now pick the minimum version between all duplicated target engines.

* Force `.mp3` files to use the `audio/mpeg` MIME type ([#4485](https://github.com/evanw/esbuild/issues/4485))

    MIME type detection for esbuild's data URLs uses Go's built-in MIME type detection, which is based on the [MIME sniffing standard](https://mimesniff.spec.whatwg.org/). This works correctly for MP3 files that start with the byte sequence `ID3`, which is commonly the case. However, it's possible to construct valid MP3 files that do not start with `ID3`, and that perhaps Go's built-in MIME type detection doesn't implement the "Signature for MP3 without ID3" part of the algorithm. This results in some `.mp3` files incorrectly using the `application/octet-stream` MIME type instead of `audio/mpeg`. With this release, esbuild will now always use the `audio/mpeg` MIME type for files ending in `.mp3`.

* Add a new TypeScript syntax warning

    TypeScript 7 turned some previously-valid TypeScript syntax into a syntax error because it was confusing. TypeScript 6 accepts `1 + 2 as number * 3` as valid syntax but confusingly converts it to `(1 + 2) * 3` instead of the more intuitive conversion to `1 + (2 * 3)`. This syntax is now an error in TypeScript 7+. With this release, esbuild will now warn about the use of this syntax:

    ```ts
    ▲ [WARNING] Operator "*" should not directly follow a TypeScript type cast after the "+" operator [confusing-typescript-cast]

        example.ts:1:28:
          1 │ console.log(1 + 2 as number * 3)
            ╵                             ^

      This is a syntax error in newer versions of TypeScript because the type cast has unintuitive
      precedence in this case. Surround the inner expression in parentheses to silence this warning:

        example.ts:1:12:
          1 │ console.log(1 + 2 as number * 3)
            │             ~~~~~~~~~~~~~~~
            ╵             (             )
    ```

    See [microsoft/TypeScript#63527](https://github.com/microsoft/TypeScript/issues/63527) for more information.

* Add support for formatting errors for Visual Studio ([#4460](https://github.com/evanw/esbuild/issues/4460))

    Visual Studio has a specific style that it expects log messages to be in for them to show up in the UI when esbuild is run as a custom build step. The current log style that esbuild uses doesn't conform to this specific style.

    With this release, esbuild has a new log style for Visual Studio (and other tools in the MSBuild ecosystem) that can be enabled with `--log-style=visualstudio`. Here is an example log message in this style:

    ```
    $ esbuild example.ts --log-style=visualstudio
    /Users/evan/dev/esbuild/example.ts(1,29): warning ES0010: Operator "*" should not directly follow a TypeScript type cast after the "+" operator
    ```

    This log style is also available via the JS and Go APIs, and can now be used with the existing `formatMessages` API.

* Fix a bug with CSS gamut mapping ([#4488](https://github.com/evanw/esbuild/pull/4488))

    Due to a typo, the fallback colors generated for CSS colors outside of the sRGB gamut weren't correct. This release fixes the generated colors to use the intended algorithm.

    This fix was submitted by [@chatman-media](https://github.com/chatman-media).

## 0.28.1

* Disallow ``\`` in local development server HTTP requests ([GHSA-g7r4-m6w7-qqqr](https://github.com/evanw/esbuild/security/advisories/GHSA-g7r4-m6w7-qqqr))

    This release fixes a security issue where HTTP requests to esbuild's local development server could traverse outside of the serve directory on Windows using a ``\`` backslash character. It happened due to the use of Go's `path.Clean()` function, which only handles Unix-style `/` characters. HTTP requests with paths containing ``\`` are no longer allowed.

    Thanks to [@dellalibera](https://github.com/dellalibera) for reporting this issue.

* Add integrity checks to the Deno API ([GHSA-gv7w-rqvm-qjhr](https://github.com/evanw/esbuild/security/advisories/GHSA-gv7w-rqvm-qjhr))

    The previous release of esbuild added integrity checks to esbuild's npm install script. This release also adds integrity checks to esbuild's Deno install script. Now esbuild's Deno API will also fail with an error if the downloaded esbuild binary contains something other than the expected content.

    Note that esbuild's Deno API installs from `registry.npmjs.org` by default, but allows the `NPM_CONFIG_REGISTRY` environment variable to override this with a custom package registry. This change means that the esbuild executable served by `NPM_CONFIG_REGISTRY` must now match the expected content.

    Thanks to [@sondt99](https://github.com/sondt99) for reporting this issue.

* Avoid inlining `using` and `await using` declarations ([#4482](https://github.com/evanw/esbuild/issues/4482))

    Previously esbuild's minifier sometimes incorrectly inlined `using` and `await using` declarations into subsequent uses of that declaration, which then fails to dispose of the resource correctly. This bug happened because inlining was done for `let` and `const` declarations by avoiding doing it for `var` declarations, which no longer worked when more declaration types were added. Here's an example:

    ```js
    // Original code
    {
      using x = new Resource()
      x.activate()
    }

    // Old output (with --minify)
    new Resource().activate();

    // New output (with --minify)
    {using e=new Resource;e.activate()}
    ```

* Fix module evaluation when an error is thrown ([#4461](https://github.com/evanw/esbuild/issues/4461), [#4467](https://github.com/evanw/esbuild/pull/4467))

    If an error is thrown during module evaluation, esbuild previously didn't preserve the state of the module for subsequent module references. This was observable if `import()` or `require()` is used to import a module multiple times. The thrown error is supposed to be thrown by every call to `import()` or `require()`, not just the first. With this release, esbuild will now throw the same error every time you call `import()` or `require()` on a module that throws during its evaluation.

* Fix some edge cases around the `new` operator ([#4477](https://github.com/evanw/esbuild/issues/4477))

    Previously esbuild incorrectly printed certain edge cases involving complex expressions inside the target of a `new` expression (specifically an optional chain and/or a tagged template literal). The generated code for the `new` target was not correctly wrapped with parentheses, and either contained a syntax error or had different semantics. These edge cases have been fixed so that they now correctly wrap the `new` target in parentheses. Here is an example of some affected code:

    ```js
    // Original code
    new (foo()`bar`)()
    new (foo()?.bar)()

    // Old output
    new foo()`bar`();
    new (foo())?.bar();

    // New output
    new (foo())`bar`();
    new (foo()?.bar)();
    ```

* Fix renaming of nested `var` declarations ([#4471](https://github.com/evanw/esbuild/issues/4471))

    This release fixes a bug where `var` declarations in nested scopes that are hoisted up to module scope were not correctly being renamed during bundling. That could previously lead to name collisions when minification was disabled, which could potentially cause a behavior change. The bug has been fixed so that these hoisted declarations are now considered to be module-level symbols during the name collision avoidance pass.

* Emit `var` instead of `const` for certain TypeScript-only constructs for ES5 ([#4448](https://github.com/evanw/esbuild/issues/4448))

    While esbuild doesn't generally support converting `const` to `var` for ES5 due to nested scoping rules (which is currently a build-time error), esbuild previously incorrectly converted TypeScript-only `import` assignment constructs into a `const` declaration even when targeting ES5. With this release, esbuild will now use `var` for this case instead:

    ```js
    // Original code
    import x = require('y')

    // Old output (with --target=es5)
    const x = require("y");

    // New output (with --target=es5)
    var x = require("y");
    ```

## 0.28.0

* Add support for `with { type: 'text' }` imports ([#4435](https://github.com/evanw/esbuild/issues/4435))

    The [import text](https://github.com/tc39/proposal-import-text) proposal has reached stage 3 in the TC39 process, which means that it's recommended for implementation. It has also already been implemented by [Deno](https://docs.deno.com/examples/importing_text/) and [Bun](https://bun.com/docs/guides/runtime/import-html). So with this release, esbuild also adds support for it. This behaves exactly the same as esbuild's existing [`text` loader](https://esbuild.github.io/content-types/#text). Here's an example:

    ```js
    import string from './example.txt' with { type: 'text' }
    console.log(string)
    ```

* Add integrity checks to fallback download path ([#4343](https://github.com/evanw/esbuild/issues/4343))

    Installing esbuild via npm is somewhat complicated with several different edge cases (see [esbuild's documentation](https://esbuild.github.io/getting-started/#additional-npm-flags) for details). If the regular installation of esbuild's platform-specific package fails, esbuild's install script attempts to download the platform-specific package itself (first with the `npm` command, and then with a HTTP request to `registry.npmjs.org` as a last resort).

    This last resort path previously didn't have any integrity checks. With this release, esbuild will now verify that the hash of the downloaded binary matches the expected hash for the current release. This means the hashes for all of esbuild's platform-specific binary packages will now be embedded in the top-level `esbuild` package. Hopefully this should work without any problems. But just in case, this change is being done as a breaking change release.

* Update the Go compiler from 1.25.7 to 1.26.1

    This upgrade should not affect anything. However, there have been some significant internal changes to the Go compiler, so esbuild could potentially behave differently in certain edge cases:

    - It now uses the [new garbage collector](https://go.dev/doc/go1.26#new-garbage-collector) that comes with Go 1.26.
    - The Go compiler is now more aggressive with allocating memory on the stack.
    - The executable format that the Go linker uses has undergone several changes.
    - The WebAssembly build now unconditionally makes use of the sign extension and non-trapping floating-point to integer conversion instructions.

    You can read the [Go 1.26 release notes](https://go.dev/doc/go1.26) for more information.

## 0.27.7

* Fix lowering of define semantics for TypeScript parameter properties ([#4421](https://github.com/evanw/esbuild/issues/4421))

    The previous release incorrectly generated class fields for TypeScript parameter properties even when the configured target environment does not support class fields. With this release, the generated class fields will now be correctly lowered in this case:

    ```ts
    // Original code
    class Foo {
      constructor(public x = 1) {}
      y = 2
    }

    // Old output (with --loader=ts --target=es2021)
    class Foo {
      constructor(x = 1) {
        this.x = x;
        __publicField(this, "y", 2);
      }
      x;
    }

    // New output (with --loader=ts --target=es2021)
    class Foo {
      constructor(x = 1) {
        __publicField(this, "x", x);
        __publicField(this, "y", 2);
      }
    }
    ```

## 0.27.5

* Fix for an async generator edge case ([#4401](https://github.com/evanw/esbuild/issues/4401), [#4417](https://github.com/evanw/esbuild/pull/4417))

    Support for transforming async generators into the equivalent state machine was added in version 0.19.0. However, the generated state machine didn't work correctly when polling async generators concurrently, such as in the following code:

    ```js
    async function* inner() { yield 1; yield 2 }
    async function* outer() { yield* inner() }
    let gen = outer()
    for await (let x of [gen.next(), gen.next()]) console.log(x)
    ```

    Previously esbuild's output of the above code behaved incorrectly when async generators were transformed (such as with `--supported:async-generator=false`). The transformation should be fixed starting with this release.

    This fix was contributed by [@2767mr](https://github.com/2767mr).

* Fix a regression when `metafile` is enabled ([#4420](https://github.com/evanw/esbuild/issues/4420), [#4418](https://github.com/evanw/esbuild/pull/4418))

    This release fixes a regression introduced by the previous release. When `metafile: true` was enabled in esbuild's JavaScript API, builds with build errors were incorrectly throwing an error about an empty JSON string instead of an object containing the build errors.

* Use define semantics for TypeScript parameter properties ([#4421](https://github.com/evanw/esbuild/issues/4421))

    Parameter properties are a TypeScript-specific code generation feature that converts constructor parameters into class fields when they are prefixed by certain keywords. When `"useDefineForClassFields": true` is present in `tsconfig.json`, the TypeScript compiler automatically generates class field declarations for parameter properties. Previously esbuild didn't do this, but esbuild will now do this starting with this release:

    ```ts
    // Original code
    class Foo {
      constructor(public x: number) {}
    }

    // Old output (with --loader=ts)
    class Foo {
      constructor(x) {
        this.x = x;
      }
    }

    // New output (with --loader=ts)
    class Foo {
      constructor(x) {
        this.x = x;
      }
      x;
    }
    ```

* Allow `es2025` as a target in `tsconfig.json` ([#4432](https://github.com/evanw/esbuild/issues/4432))

    TypeScript recently [added `es2025`](https://devblogs.microsoft.com/typescript/announcing-typescript-6-0/#es2025-option-for-target-and-lib) as a compilation target, so esbuild now supports this in the `target` field of `tsconfig.json` files, such as in the following configuration file:

    ```json
    {
      "compilerOptions": {
        "target": "ES2025"
      }
    }
    ```

    As a reminder, the only thing that esbuild uses this field for is determining whether or not to use legacy TypeScript behavior for class fields. You can read more in [the documentation](https://esbuild.github.io/content-types/#tsconfig-json).

## 0.27.4

* Fix a regression with CSS media queries ([#4395](https://github.com/evanw/esbuild/issues/4395), [#4405](https://github.com/evanw/esbuild/issues/4405), [#4406](https://github.com/evanw/esbuild/issues/4406))

    Version 0.25.11 of esbuild introduced support for parsing media queries. This unintentionally introduced a regression with printing media queries that use the `<media-type> and <media-condition-without-or>` grammar. Specifically, esbuild was failing to wrap an `or` clause with parentheses when inside `<media-condition-without-or>`. This release fixes the regression.

    Here is an example:

    ```css
    /* Original code */
    @media only screen and ((min-width: 10px) or (min-height: 10px)) {
      a { color: red }
    }

    /* Old output (incorrect) */
    @media only screen and (min-width: 10px) or (min-height: 10px) {
      a {
        color: red;
      }
    }

    /* New output (correct) */
    @media only screen and ((min-width: 10px) or (min-height: 10px)) {
      a {
        color: red;
      }
    }
    ```

* Fix an edge case with the `inject` feature ([#4407](https://github.com/evanw/esbuild/issues/4407))

    This release fixes an edge case where esbuild's `inject` feature could not be used with arbitrary module namespace names exported using an `export {} from` statement with bundling disabled and a target environment where arbitrary module namespace names is unsupported.

    With the fix, the following `inject` file:

    ```js
    import jquery from 'jquery';
    export { jquery as 'window.jQuery' };
    ```

    Can now always be rewritten as this without esbuild sometimes incorrectly generating an error:

    ```js
    export { default as 'window.jQuery' } from 'jquery';
    ```

* Attempt to improve API handling of huge metafiles ([#4329](https://github.com/evanw/esbuild/issues/4329), [#4415](https://github.com/evanw/esbuild/issues/4415))

    This release contains a few changes that attempt to improve the behavior of esbuild's JavaScript API with huge metafiles (esbuild's name for the build metadata, formatted as a JSON object). The JavaScript API is designed to return the metafile JSON as a JavaScript object in memory, which makes it easy to access from within a JavaScript-based plugin. Multiple people have encountered issues where this API breaks down with a pathologically-large metafile.

    The primary issue is that V8 has an implementation-specific maximum string length, so using the `JSON.parse` API with large enough strings is impossible. This release will now attempt to use a fallback JavaScript-based JSON parser that operates directly on the UTF8-encoded JSON bytes instead of using `JSON.parse` when the JSON metafile is too big to fit in a JavaScript string. The new fallback path has not yet been heavily-tested. The metafile will also now be generated with whitespace removed if the bundle is significantly large, which will reduce the size of the metafile JSON slightly.

    However, hitting this case is potentially a sign that something else is wrong. Ideally you wouldn't be building something so enormous that the build metadata can't even fit inside a JavaScript string. You may want to consider optimizing your project, or breaking up your project into multiple parts that are built independently. Another option could potentially be to use esbuild's command-line API instead of its JavaScript API, which is more efficient (although of course then you can't use JavaScript plugins, so it may not be an option).

## 0.27.3

* Preserve URL fragments in data URLs ([#4370](https://github.com/evanw/esbuild/issues/4370))

    Consider the following HTML, CSS, and SVG:

    * `index.html`:

        ```html
        <!DOCTYPE html>
        <html>
          <head><link rel="stylesheet" href="icons.css"></head>
          <body><div class="triangle"></div></body>
        </html>
        ```

    * `icons.css`:

        ```css
        .triangle {
          width: 10px;
          height: 10px;
          background: currentColor;
          clip-path: url(./triangle.svg#x);
        }
        ```

    * `triangle.svg`:

        ```xml
        <svg xmlns="http://www.w3.org/2000/svg">
          <defs>
            <clipPath id="x">
              <path d="M0 0H10V10Z"/>
            </clipPath>
          </defs>
        </svg>
        ```

    The CSS uses a URL fragment (the `#x`) to reference the `clipPath` element in the SVG file. Previously esbuild's CSS bundler didn't preserve the URL fragment when bundling the SVG using the `dataurl` loader, which broke the bundled CSS. With this release, esbuild will now preserve the URL fragment in the bundled CSS:

    ```css
    /* icons.css */
    .triangle {
      width: 10px;
      height: 10px;
      background: currentColor;
      clip-path: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg"><defs><clipPath id="x"><path d="M0 0H10V10Z"/></clipPath></defs></svg>#x');
    }
    ```

* Parse and print CSS `@scope` rules ([#4322](https://github.com/evanw/esbuild/issues/4322))

    This release includes dedicated support for parsing `@scope` rules in CSS. These rules include optional "start" and "end" selector lists. One important consequence of this is that the local/global status of names in selector lists is now respected, which improves the correctness of esbuild's support for [CSS modules](https://esbuild.github.io/content-types/#local-css). Minification of selectors inside `@scope` rules has also improved slightly.

    Here's an example:

    ```css
    /* Original code */
    @scope (:global(.foo)) to (:local(.bar)) {
      .bar {
        color: red;
      }
    }

    /* Old output (with --loader=local-css --minify) */
    @scope (:global(.foo)) to (:local(.bar)){.o{color:red}}

    /* New output (with --loader=local-css --minify) */
    @scope(.foo)to (.o){.o{color:red}}
    ```

* Fix a minification bug with lowering of `for await` ([#4378](https://github.com/evanw/esbuild/pull/4378), [#4385](https://github.com/evanw/esbuild/pull/4385))

    This release fixes a bug where the minifier would incorrectly strip the variable in the automatically-generated `catch` clause of lowered `for await` loops. The code that generated the loop previously failed to mark the internal variable references as used.

* Update the Go compiler from v1.25.5 to v1.25.7 ([#4383](https://github.com/evanw/esbuild/issues/4383), [#4388](https://github.com/evanw/esbuild/pull/4388))

    This PR was contributed by [@MikeWillCook](https://github.com/MikeWillCook).

## 2025

All esbuild versions published in the year 2025 (versions 0.25.0 through 0.27.2) can be found in [CHANGELOG-2025.md](./CHANGELOG-2025.md).

## 2024

All esbuild versions published in the year 2024 (versions 0.19.12 through 0.24.2) can be found in [CHANGELOG-2024.md](./CHANGELOG-2024.md).

## 2023

All esbuild versions published in the year 2023 (versions 0.16.13 through 0.19.11) can be found in [CHANGELOG-2023.md](./CHANGELOG-2023.md).

## 2022

All esbuild versions published in the year 2022 (versions 0.14.11 through 0.16.12) can be found in [CHANGELOG-2022.md](./CHANGELOG-2022.md).

## 2021

All esbuild versions published in the year 2021 (versions 0.8.29 through 0.14.10) can be found in [CHANGELOG-2021.md](./CHANGELOG-2021.md).

## 2020

All esbuild versions published in the year 2020 (versions 0.3.0 through 0.8.28) can be found in [CHANGELOG-2020.md](./CHANGELOG-2020.md).
