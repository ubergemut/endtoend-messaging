export default 'dynamic ok'
