export const global = 'ok'
